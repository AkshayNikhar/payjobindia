<!--All Vertical Pages-->
 <body data-sidebar="dark">
<?php 
// echo $_SESSION["email"];
?>
<!-- if you select authentication And Utility pages then comment all body tags and uncomment this-->
<!--<body>-->

<!--if you select layout box then comment all body tags and uncomment this -->
<!--<body data-sidebar="dark" data-keep-enlarged="true" class="vertical-collpsed" data-layout-size="boxed">-->

<!--if you select layouts colored sidebar then comment all body tags and uncomment this -->
<!--<body data-sidebar="colored">-->

<!--if you select layouts compact sidebar then comment all body tags and uncomment this -->
<!--<body data-sidebar="dark" data-sidebar-size="small">-->

<!--if you select layouts Horizontal boxed then comment all body tags and uncomment this -->
<!--<body data-topbar="dark" data-layout="horizontal" data-layout-size="boxed">-->

<!--if you select layouts Horizontal colored then comment all body tags and uncomment this  -->
<!--<body data-topbar="colored" data-layout="horizontal">-->

<!--if you select Layouts Horizontal Topbar light then comment all body tags and uncomment this -->
<!--<body data-topbar="light" data-layout="horizontal">-->

<!--if you select layouts Horizontal then comment all body tags and uncomment this  -->
<!--<body data-topbar="dark" data-layout="horizontal">-->

<!--if you select layouts icon sidebar then comment all body tags and uncomment this  -->
<!--<body data-sidebar="dark" data-keep-enlarged="true" class="vertical-collpsed">-->

<!--if you select layouts light sidebar then comment all body tags and uncomment this -->
<body data-topbar="dark">

<!--if you select crypto ico landing then comment all body tags and uncomment this -->
<!--<body data-spy="scroll" data-target="#topnav-menu" data-offset="60">-->

<!--if you select layouts Horizontal Scrollable then comment all body tags and uncomment this  -->
<!--<body data-topbar="dark" data-layout="horizontal" data-layout-scrollable="true">-->

<!--if you select layouts Vertical Scrollable then comment all body tags and uncomment this  -->
<!--<body data-sidebar="dark" data-layout-scrollable="true">-->
