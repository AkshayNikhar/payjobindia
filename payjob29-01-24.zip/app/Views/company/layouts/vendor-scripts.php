<!-- JAVASCRIPT -->
<script src="<?php echo base_url() ?>/back/assets/libs/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ?>/back/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>/back/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="<?php echo base_url() ?>/back/assets/libs/simplebar/simplebar.min.js"></script>
<script src="<?php echo base_url() ?>/back/assets/libs/node-waves/waves.min.js"></script>