
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Advert Studio Admin" name="description"/>
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo base_url() ?>/front/assets/images/resources/favicon.png">


<style>
    .footer {
    bottom: 0;
    padding: 12px calc(24px / 2);
    position: absolute;
    right: 0;
    color: #ffffff;
    left: 250px;
    height: 40px;
    background-color: #000000;
}

</style>