<!-- JAVASCRIPT -->
<?php include 'vendor-scripts.php'; ?>

<!--<script src="<?php echo base_url('assets/libs/jquery/jquery.min.js') ?>"></script>-->
<!-- Required datatable js -->
<script src="<?php echo base_url('/back/assets/libs/datatables.net/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') ?>"></script>
<!-- Buttons examples -->
<script src="<?php echo base_url('/back/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/jszip/jszip.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/pdfmake/build/pdfmake.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/pdfmake/build/vfs_fonts.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-buttons/js/buttons.html5.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-buttons/js/buttons.print.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js') ?>"></script>

<!-- Responsive examples -->
<script src="<?php echo base_url('/back/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js') ?>"></script>

<!-- Datatable init js -->
<script src="<?php echo base_url('/back/assets/js/pages/datatables.init.js') ?>"></script>

<script src="<?php echo base_url('/back/assets/js/app.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/js/pages/form-advanced.init.js') ?>"></script>

<script src="<?php echo base_url('/back/assets/libs/select2/js/select2.min.js') ?>"></script>
<script src="<?php echo base_url('/back/assets/libs/parsleyjs/parsley.min.js') ?>"></script>

<script src="<?php echo base_url('/back/assets/js/pages/form-validation.init.js') ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- dragula plugins -->
<script src="<?php echo base_url('/back/assets/libs/dragula/dragula.min.js')?>"></script>
<script src="<?php echo base_url('/back/assets/js/pages/task-kanban.init.js')?>"></script>
<!--<script src="<?php echo base_url('/back/assets/js/pages/task-form.init.js')?>"></script>-->
<script>
    CKEDITOR.replace('editor')
</script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
$('.select2').select2({
// multiple: "multiple",
});

});
</script>

