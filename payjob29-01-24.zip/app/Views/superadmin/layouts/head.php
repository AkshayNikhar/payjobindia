
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="Farmeasy Admin" name="description"/>
<!-- App favicon -->
<link rel="shortcut icon" href="https://demo.payjobindia.com/img/favicon.png">
<!--<link rel="shortcut icon" href="<?php echo base_url() ?>/front/assets/img/Farm Easy Web Icon.png">-->

<!-- DataTables -->
<link href="<?php echo base_url() ?>/back/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>/back/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Responsive datatable examples -->
<link href="<?php echo base_url() ?>/back/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="https://htmlstream.com/preview/front-v2.9.0/assets/vendor/bootstrap-tagsinput/css/bootstrap-tagsinput.css" rel="stylesheet" type="text/css">

<style>
    .footer {
    bottom: 0;
    padding: 12px calc(24px / 2);
    position: absolute;
    right: 0;
    color: #ffffff;
    left: 250px;
    height: 40px;
    background-color: #000000;
}
.bootstrap-tagsinput .tag {
            position: relative;
            display: inline-table;
            font-size: .875rem;
            color: #77838f;
            background-color: rgba(119, 131, 143, 0.1);
            border-radius: 0.3125rem;
            padding: 0.25rem 0.81rem 0.25rem 0.5rem;;
            margin-bottom: 0.25rem;
            margin-right: 0;
        }
        .bootstrap-tagsinput{
              display: inherit;
        }
</style>