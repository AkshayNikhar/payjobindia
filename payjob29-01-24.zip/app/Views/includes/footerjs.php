<!--<script src="<?php echo base_url('front/assets/js/jquery-3.6.0.min.js') ?>"></script>-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="<?php echo base_url('front/assets/js/jquery-ui.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/bootstrap.bundle.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/swiper-bundle.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/jquery.fancybox.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/slick.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/summernote.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/jquery.waypoints.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/counterup.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/select2.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/viewport.jquery.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/jquery.nice-number.min.js') ?>"></script>
	<script src="<?php echo base_url('front/assets/js/main.js') ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
    <script>
        // Initialize Select2
        $(document).ready(function() {
            // $('.custom-select').select2();
            $('.js-example-basic-single').select2();
        });
    </script>
	
	<script>
    function wishlistform(jobId, userId) {
        $("#wishbtn_" + jobId).html('<i class="fa fa-spinner"></i>');
        $.ajax({
            url: "<?php echo base_url('/jobs-save-by-user')?>",
            type: 'POST',
            data: {"JobID": jobId, "userId": userId},
            success: function(result) {
                if (result.status == 200) {
                    $("#wishbtn_" + jobId).html('<i class="bi bi-bookmark-heart"></i>');
                    $("#wishbtn_" + jobId).css('background', '#70d100');
                    toastr.success(result.msg);
                } else {
                    $("#wishbtn_" + jobId).html('<i class="bi bi-bookmark"></i>');
                    toastr.info(result.msg);
                }
            },
            error: function(data) {
                console.log(data);
            }
        });
    }
</script>


<script>
// 		Slider category
		/*$('.cat-slider').owlCarousel({
			loop: true,
			margin: 10,
			nav: true,
			dots: false,
			autoWidth: true,
			autoplay: true,
			slideTransition: 'linear',
			autoplayTimeout: 2000,
			autoplaySpeed: 2000,
			autoplayHoverPause: true,
			responsive: {
				0: {
					items: 2
				},
				600: {
					items: 3
				},
				1000: {
					items: 6
				}
			}
		})*/
		
		 $(document).ready(function(){
        $('.cat-slider').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            dots: false,
            autoWidth: true,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 2000,
            autoplaySpeed: 2000,
            autoplayHoverPause: true,
            responsive: {
                0: { items: 2 },
                600: { items: 3 },
                1000: { items: 6 }
            }
        });
    });
// 		Show all Category
		$('.moreless-button').click(function() {
			$('.moretext').slideToggle();
			if($('.moreless-button').text() == "Show All") {
				$(this).text("Show Less")
			} else {
				$(this).text("Show All")
			}
		});
// 		Show all Job
		$('.moreless-button1').click(function() {
			$('.moretext1').slideToggle();
			if($('.moreless-button').text() == "Show All") {
				$(this).text("Show Less")
			} else {
				$(this).text("Show All")
			}
		});
// 		Counter
		$(document).ready(function() {
			$('.odometer').each(function() {
				$(this).prop('Counter', 0).animate({
					Counter: $(this).text()
				}, {
					duration: 3500, 
					easing: 'swing',
					step: function(now) {
						$(this).text(Math.ceil(now));
					}
				});
			});
		});
		</script>
