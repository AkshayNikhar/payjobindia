<?php

namespace App\Models;

use CodeIgniter\Model;

class CommonModel extends Model
{

	public function insertData($table,$data=array())
	{
      $query = $this->db->table($table);
	  $result = $query->insert($data);
      return  $this->db->insertID();
	}

	public function updateData($table,$data =array(),$condition= array())
	{
			$query = $this->db->table($table);
			return  $query->update($data, $condition);
		 
	}

	public function deleteData($table,$condition =array())
	{
			$query= $this->db->table($table);
			return  $query->delete($condition);  
	}
	
	// fetch single record
	public function fs($table,$condition= array())
	{
		$query= $this->db->table($table);
		return $query->getWhere($condition)->getrow();
	}

	public function fs_desc($table,$condition= array(),$column = 'id',$sort_order = 'desc')
	{
		$query= $this->db->table($table);
		return $query->orderBy($column,$sort_order)->getWhere($condition)->getrow();
	}

	public function allFetch($table,$condition= array(),$column = 'id',$sort_order = 'asc',$limit = NULL,$offset = NULL)
	{		
		$query= $this->db->table($table);
		return $query->orderBy($column,$sort_order)->getWhere($condition,$limit,$offset)->getResult();
	}
    public function allFetchd($table,$condition= array(),$column = 'id',$sort_order = 'desc',$limit = NULL,$offset = NULL)
	{		
		$query= $this->db->table($table);
		return $query->orderBy($column,$sort_order)->getWhere($condition,$limit,$offset)->getResult();
		
	}
    public function all_fetch_array($table,$condition= array(),$column = 'id',$sort_order = 'asc',$limit = NULL,$offset = NULL)
	{		
		$query= $this->db->table($table);
		return $query->orderBy($column,$sort_order)->getWhere($condition,$limit,$offset)->getResult('array');
		
	}

	public function allCount($table,$condition= array())
	{
		$query= $this->db->table($table);
		return $query->where($condition)->countAllResults();
		
	}
	
	public function getLastQuery()
    {
        return $this->db->getLastQuery();
    }
    
    
    
    //search start
    // protected $table = 'jobs_list';
    public function getStateList()
    {
        return $this->allFetchd('location_states', array('is_active' => 1));
    }

    public function getCityList()
    {
        return $this->allFetchd('location_cities', array('is_active' => 1));
    }

    public function searchJobs($jobTitle, $stateId, $cityId)
    {
        $builder = $this->db->table('jobs_list');
        $builder->select('*');
        $builder->where('is_active', 1);
        
        if (!empty($jobTitle)) {
        $builder->like('title', $jobTitle);
        }
        
        if (!empty($stateId)) {
            $builder->where('state_id', $stateId);
        }
        
        if (!empty($cityId)) {
            $builder->where('city_id', $cityId);
        }
        
        // $builder->select('jobs_list.*, cities.city_name, states.state_name');
        // $builder->join('cities', 'cities.id = jobs_list.city_id', 'left');
        // $builder->join('states', 'states.id = jobs_list.state_id', 'left');
        // $builder->where('jobs_list.is_active', 1);
        
        // if (!empty($jobTitle)) {
        // $builder->like('jobs_list.title', $jobTitle);
        // }
    
        // if (!empty($stateId)) {
        //     $builder->where('jobs_list.state_id', $stateId);
        // }
    
        // if (!empty($cityId)) {
        //     $builder->where('jobs_list.city_id', $cityId);
        // }

        // print_r($builder);
        // exit;
        
        // echo '<pre>'; print_r($builder); echo '</pre>';
        // echo $this->getLastQuery(); exit;
        return $builder->get()->getResultArray();
    }
    
    /*public function searchJobs($jobTitle, $stateId, $cityId)
    {
    $builder = $this->db->table('jobs_list');
    $builder->select('jobs_list.*, cities.city_name, states.state_name');
    $builder->join('cities', 'cities.id = jobs_list.city_id', 'left');
    $builder->join('states', 'states.id = jobs_list.state_id', 'left');
    $builder->where('jobs_list.is_active', 1);

     if (!empty($jobTitle)) {
        $builder->groupStart(); // Group the LIKE conditions
        $builder->like('jobs_list.title', $jobTitle);
        $builder->orLike('jobs_list.another_column', $jobTitle); // Add more conditions if needed
        $builder->groupEnd(); // End the grouped conditions
    }

    if (!empty($stateId)) {
        $builder->where('jobs_list.state_id', $stateId);
    }

    if (!empty($cityId)) {
        $builder->where('jobs_list.city_id', $cityId);
    }

    $result = $builder->get();

    if ($result) {
        return $result->getResultArray();
    } else {
        // Log or handle the error appropriately
        return [];
    }
}*/


    //search end
	
//end here
}
